# Story → Shopee — Passo a passo do deploy (GitHub → Netlify)

Como o site grava os vídeos no **servidor** (Netlify Blobs), o deploy tem que rodar
o build (instalar dependência + empacotar as funções). Por isso é via GitHub, não
por arrastar-e-soltar. É grátis e **não precisa de VPS**.

## Estrutura da pasta (já está montada no ZIP)

```
story-shopee/
├── netlify.toml
├── package.json
├── public/
│   └── index.html          ← o painel (desktop)
└── netlify/
    └── functions/
        ├── check.js        ← captura o story, baixa e grava a mídia
        ├── media.js        ← serve a mídia gravada
        ├── history.js      ← lê o histórico por data
        └── remove.js       ← apaga uma captura
```

## Deploy em 6 passos (tudo pelo navegador, sem instalar nada)

1. Crie uma conta no **GitHub** (github.com) e no **Netlify** (netlify.com) — grátis.
2. No GitHub: **New repository** → nome (ex: `story-shopee`) → **Create**.
3. Na página do repositório: **Add file → Upload files**. Arraste **o conteúdo da
   pasta `story-shopee`** (o `netlify.toml`, `package.json`, a pasta `public` e a
   pasta `netlify`). Depois **Commit changes**.
   - Dica: dá pra arrastar as pastas inteiras; o GitHub mantém a estrutura.
4. No Netlify: **Add new site → Import an existing project → GitHub** → escolha o
   repositório `story-shopee`.
5. Deixe as configurações como vierem (o `netlify.toml` já define tudo:
   publish = `public`, functions = `netlify/functions`). Clique **Deploy**.
6. Em ~1 minuto o site fica no ar num endereço tipo
   `https://seu-nome.netlify.app`. Pronto.

## Cookie do Instagram (opcional, mas recomendado)

Sem cookie funciona para muitas contas públicas, mas o Instagram às vezes bloqueia
(erro 401/429). Duas formas de usar cookie:

- **Rápido:** no painel, botão **🍪 Cookie**, cole o cookie e salve (fica só no seu
  navegador). Use a extensão **Get cookies.txt LOCALLY** no instagram.com logado; o
  essencial é a linha `sessionid=...`.
- **Fixo pra sempre:** no Netlify em **Site settings → Environment variables**, crie
  `IG_COOKIE` com o valor do cookie. Aí vale pra qualquer acesso, sem colar toda vez.

## Como usar

1. Cole o `@usuario` no topo e clique **Check Story**.
2. O site baixa cada vídeo/imagem, **grava no servidor** e mostra os criativos com:
   - **⬇ Baixar** (salva o vídeo)
   - **↗ Compartilhar** (no celular abre o share sheet do Instagram/WhatsApp; no
     desktop baixa o arquivo)
   - Os **links da Shopee** em destaque laranja, com **Abrir** (no celular tenta o
     deep link `shopee://`; no desktop abre no navegador).
3. Tudo fica no **histórico lateral por data**. Clique em qualquer dia/conta para
   reabrir os criativos — **mesmo depois do story ter expirado**, porque a mídia
   está gravada no servidor.

## Limitações honestas

- **Contas privadas** não dá para ver stories.
- O Instagram pode retornar erro se detectar scraping; nesse caso aparece uma
  mensagem clara e você tenta de novo (o cookie ajuda muito).
- Netlify Blobs no plano grátis tem cota generosa, mas se você guardar MUITOS vídeos
  por muito tempo, um dia pode chegar no limite — aí é só apagar capturas antigas
  (botão ✕ no histórico) ou subir de plano.
